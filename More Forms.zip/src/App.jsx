import { useState } from 'react'
import './App.css'
import Newform from './Components/Newform'


function App() {

  return (
    <>
      <Newform/>
    </>
  )
}

export default App
